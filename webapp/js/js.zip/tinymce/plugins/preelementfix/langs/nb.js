tinyMCE.addI18n('nb.preelementfix',{
  mei_remove_css_class: 'Fjern CSS-alias'
});